using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using FastReport;
using FastReport.Design;
using FastReport.MSChart;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using CrystalDecisions.ReportAppServer;

namespace FastReport.Design.ImportPlugins.RPT
{
    /// <summary>
    /// Represents the RPT import plugin.
    /// </summary>
    public class RPTImportPlugin : ImportPlugin
    {
        #region Fields

        private ReportPage page;
        private ReportClass crystalReport;

        #endregion // Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="RPTImportPlugin"/> class.
        /// </summary>
        public RPTImportPlugin()
            : base()
        {
            Initialize();
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RPTImportPlugin"/> class with a specified designer.
        /// </summary>
        public RPTImportPlugin(Designer designer)
            : base(designer)
        {
            Initialize();
        }

        #endregion // Constructors

        #region Private Methods

        private void Initialize()
        {
            crystalReport = new ReportClass();
        }

        private void LoadReportInfo()
        {
            SummaryInfo summaryInfo = crystalReport.SummaryInfo;
            Report.ReportInfo.Name = UnitsConverter.ConvertString(crystalReport.Name);
            Report.ReportInfo.Author = UnitsConverter.ConvertString(summaryInfo.ReportAuthor);
            Report.ReportInfo.Description = UnitsConverter.ConvertString(summaryInfo.ReportComments);
            string filename = crystalReport.FileName.Remove(0, crystalReport.FileName.LastIndexOf("//") + 2);
            Report.ReportInfo.Created = File.GetCreationTime(filename);
            Report.ReportInfo.Modified = File.GetLastWriteTime(filename);
        }

        private void LoadPrintSettings()
        {
            PrintOptions printOptions = crystalReport.PrintOptions;
            Report.PrintSettings.Printer = printOptions.PrinterName;
            if (!String.IsNullOrEmpty(Report.PrintSettings.Printer))
            {
                Report.PrintSettings.SavePrinterWithReport = true;
            }
            Report.PrintSettings.Duplex = UnitsConverter.ConvertPrinterDuplex(printOptions.PrinterDuplex);
        }

        private void LoadPageSettings()
        {
            PrintOptions printOptions = crystalReport.PrintOptions;
            UnitsConverter.ConvertPaperSize(printOptions.PaperSize, printOptions.PaperOrientation, page);
            page.TopMargin = UnitsConverter.TwipsToMillimeters(printOptions.PageMargins.topMargin);
            page.LeftMargin = UnitsConverter.TwipsToMillimeters(printOptions.PageMargins.leftMargin);
            page.RightMargin = UnitsConverter.TwipsToMillimeters(printOptions.PageMargins.rightMargin);
            page.BottomMargin = UnitsConverter.TwipsToMillimeters(printOptions.PageMargins.bottomMargin);
        }

        private void LoadComponent(ReportObject obj, ComponentBase comp)
        {
            comp.Left = UnitsConverter.TwipsToPixels(obj.Left);
            comp.Top = UnitsConverter.TwipsToPixels(obj.Top);
            comp.Width = UnitsConverter.TwipsToPixels(obj.Width);
            comp.Height = UnitsConverter.TwipsToPixels(obj.Height);
        }

        private void LoadTextObject(CrystalDecisions.CrystalReports.Engine.TextObject crystalText, FastReport.TextObject fastText)
        {
            LoadComponent(crystalText, fastText);
            fastText.CanGrow = crystalText.ObjectFormat.EnableCanGrow;
            fastText.Font = crystalText.Font;
            fastText.TextColor = crystalText.Color;
            fastText.FillColor = crystalText.Border.BackgroundColor;
            fastText.Border.Color = crystalText.Border.BorderColor;
            fastText.Border.Lines = UnitsConverter.ConvertBorderToBorderLines(crystalText.Border);
            fastText.Border.TopLine.Style = UnitsConverter.ConvertLineStyle(crystalText.Border.TopLineStyle);
            fastText.Border.LeftLine.Style = UnitsConverter.ConvertLineStyle(crystalText.Border.LeftLineStyle);
            fastText.Border.RightLine.Style = UnitsConverter.ConvertLineStyle(crystalText.Border.RightLineStyle);
            fastText.Border.BottomLine.Style = UnitsConverter.ConvertLineStyle(crystalText.Border.BottomLineStyle);
            fastText.Border.Shadow = crystalText.Border.HasDropShadow;
            fastText.HorzAlign = UnitsConverter.ConvertAlignment(crystalText.ObjectFormat.HorizontalAlignment);
            fastText.Text = crystalText.Text;
        }

        private void LoadTextObject(CrystalDecisions.CrystalReports.Engine.FieldObject crystalField, FastReport.TextObject fastText)
        {
            LoadComponent(crystalField, fastText);
            fastText.CanGrow = crystalField.ObjectFormat.EnableCanGrow;
            fastText.Font = crystalField.Font;
            fastText.TextColor = crystalField.Color;
            fastText.FillColor = crystalField.Border.BackgroundColor;
            fastText.Border.Color = crystalField.Border.BorderColor;
            fastText.Border.Lines = UnitsConverter.ConvertBorderToBorderLines(crystalField.Border);
            fastText.Border.TopLine.Style = UnitsConverter.ConvertLineStyle(crystalField.Border.TopLineStyle);
            fastText.Border.LeftLine.Style = UnitsConverter.ConvertLineStyle(crystalField.Border.LeftLineStyle);
            fastText.Border.RightLine.Style = UnitsConverter.ConvertLineStyle(crystalField.Border.RightLineStyle);
            fastText.Border.BottomLine.Style = UnitsConverter.ConvertLineStyle(crystalField.Border.BottomLineStyle);
            fastText.Border.Shadow = crystalField.Border.HasDropShadow;
            fastText.HorzAlign = UnitsConverter.ConvertAlignment(crystalField.ObjectFormat.HorizontalAlignment);
        }

        private void LoadLineObject(CrystalDecisions.CrystalReports.Engine.LineObject crystalLine, FastReport.LineObject fastLine)
        {
            LoadComponent(crystalLine, fastLine);
            fastLine.Border.Color = crystalLine.LineColor;
            if (crystalLine.LineThickness == 0)
            {
                fastLine.Border.Width = 0.25f;
            }
            else if (crystalLine.LineThickness == 10)
            {
                fastLine.Border.Width = 0.5f;
            }
            else
            {
                fastLine.Border.Width = UnitsConverter.TwipsToPixels(crystalLine.LineThickness);
            }
            fastLine.Border.Style = UnitsConverter.ConvertLineStyle(crystalLine.LineStyle);
        }

        private void LoadPictureObject(CrystalDecisions.CrystalReports.Engine.PictureObject crystalPicture, FastReport.PictureObject fastPicture)
        {
            LoadComponent(crystalPicture, fastPicture);
            fastPicture.Border.Color = crystalPicture.Border.BorderColor;
            fastPicture.FillColor = crystalPicture.Border.BackgroundColor;
            fastPicture.Border.Lines = UnitsConverter.ConvertBorderToBorderLines(crystalPicture.Border);
            fastPicture.Border.TopLine.Style = UnitsConverter.ConvertLineStyle(crystalPicture.Border.TopLineStyle);
            fastPicture.Border.LeftLine.Style = UnitsConverter.ConvertLineStyle(crystalPicture.Border.LeftLineStyle);
            fastPicture.Border.RightLine.Style = UnitsConverter.ConvertLineStyle(crystalPicture.Border.RightLineStyle);
            fastPicture.Border.BottomLine.Style = UnitsConverter.ConvertLineStyle(crystalPicture.Border.BottomLineStyle);
            fastPicture.Border.Shadow = crystalPicture.Border.HasDropShadow;
            fastPicture.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void LoadMSChartObject(ChartObject crystalChart, MSChartObject fastChart)
        {
            LoadComponent(crystalChart, fastChart);
            fastChart.Series.Clear();
            MSChartSeries series = new MSChartSeries();
            fastChart.Series.Add(series);
            series.CreateUniqueName();
            fastChart.Chart.Series.Add(new Series());
            Legend legend = new Legend();
            fastChart.Chart.Legends.Add(legend);
            legend.Enabled = false;
            legend.BackColor = Color.Transparent;
            Title title = new Title();
            fastChart.Chart.Titles.Add(title);
            title.Visible = true;
            ChartArea chartArea = new ChartArea("Default");
            fastChart.Chart.ChartAreas.Add(chartArea);
            chartArea.BackColor = Color.Transparent;
            chartArea.AxisX = new Axis();
            chartArea.AxisX.IsMarginVisible = false;
            chartArea.AxisY = new Axis();
            chartArea.AxisY.IsMarginVisible = false;
            chartArea.Area3DStyle.LightStyle = LightStyle.None;
            fastChart.Chart.BorderlineColor = crystalChart.Border.BorderColor;
            fastChart.Chart.BorderlineDashStyle = UnitsConverter.ConvertLineStyleToChartDashStyle(crystalChart.Border.TopLineStyle);
        }

        private void LoadSubreportObject(CrystalDecisions.CrystalReports.Engine.SubreportObject crystalSubreport, FastReport.SubreportObject fastSubreport)
        {
            LoadComponent(crystalSubreport, fastSubreport);
            ReportPage subPage = ComponentsFactory.CreateReportPage(Report);
            DataBand subBand = ComponentsFactory.CreateDataBand(subPage);
            subBand.Height = 2.0f * FastReport.Utils.Units.Centimeters;
            fastSubreport.ReportPage = subPage;
        }

        private void LoadComponents(ReportObjects reportObjects, BandBase band)
        {
            foreach (ReportObject obj in reportObjects)
            {
                if (obj is CrystalDecisions.CrystalReports.Engine.TextObject)
                {
                    FastReport.TextObject text = ComponentsFactory.CreateTextObject(obj.Name, band);
                    LoadTextObject((obj as CrystalDecisions.CrystalReports.Engine.TextObject), text);
                }
                else if (obj is CrystalDecisions.CrystalReports.Engine.FieldObject)
                {
                    FastReport.TextObject text = ComponentsFactory.CreateTextObject(obj.Name, band);
                    LoadTextObject((obj as CrystalDecisions.CrystalReports.Engine.FieldObject), text);
                }
                else if (obj is CrystalDecisions.CrystalReports.Engine.LineObject)
                {
                    FastReport.LineObject line = ComponentsFactory.CreateLineObject(obj.Name, band);
                    LoadLineObject((obj as CrystalDecisions.CrystalReports.Engine.LineObject), line);
                }
                else if (obj is CrystalDecisions.CrystalReports.Engine.PictureObject)
                {
                    FastReport.PictureObject picture = ComponentsFactory.CreatePictureObject(obj.Name, band);
                    LoadPictureObject((obj as CrystalDecisions.CrystalReports.Engine.PictureObject), picture);
                }
                else if (obj is CrystalDecisions.CrystalReports.Engine.ChartObject)
                {
                    FastReport.MSChart.MSChartObject chart = ComponentsFactory.CreateMSChartObject(obj.Name, band);
                    LoadMSChartObject((obj as CrystalDecisions.CrystalReports.Engine.ChartObject), chart);
                }
                else if (obj is CrystalDecisions.CrystalReports.Engine.SubreportObject)
                {
                    FastReport.SubreportObject subreport = ComponentsFactory.CreateSubreportObject(obj.Name, band);
                    LoadSubreportObject((obj as CrystalDecisions.CrystalReports.Engine.SubreportObject), subreport);
                }
            }
        }

        private void LoadBand(Section section, BandBase band)
        {
            band.Height = UnitsConverter.TwipsToPixels(section.Height);
            band.FillColor = section.SectionFormat.BackgroundColor;
            band.StartNewPage = section.SectionFormat.EnableNewPageBefore;
            band.PrintOnBottom = section.SectionFormat.EnablePrintAtBottomOfPage;
            LoadComponents(section.ReportObjects, band);
        }

        private void LoadChildBand(Section section, BandBase band)
        {
            if (band.Child == null)
            {
                LoadBand(section, ComponentsFactory.CreateChildBand(band));
            }
            else
            {
                LoadChildBand(section, band.Child);
            }
        }

        private void LoadReportTitle(Section section)
        {
            if (page.ReportTitle == null)
            {
                LoadBand(section, ComponentsFactory.CreateReportTitleBand(page));
            }
            else
            {
                LoadChildBand(section, page.ReportTitle);
            }
        }

        private void LoadPageHeader(Section section)
        {
            if (page.PageHeader == null)
            {
                LoadBand(section, ComponentsFactory.CreatePageHeaderBand(page));
            }
            else
            {
                LoadChildBand(section, page.PageHeader);
            }
        }

        private void LoadReportSummary(Section section)
        {
            if (page.ReportSummary == null)
            {
                LoadBand(section, ComponentsFactory.CreateReportSummaryBand(page));
            }
            else
            {
                LoadChildBand(section, page.ReportSummary);
            }
        }

        private void LoadPageFooter(Section section)
        {
            if (page.PageFooter == null)
            {
                LoadBand(section, ComponentsFactory.CreatePageFooterBand(page));
            }
            else
            {
                LoadChildBand(section, page.PageFooter);
            }
        }

        private void LoadData(Section section)
        {
            LoadBand(section, ComponentsFactory.CreateDataBand(page));
        }

        private void LoadSections()
        {
            Sections sections = crystalReport.ReportDefinition.Sections;
            GroupHeaderBand groupHeader = null;
            DataBand detail = null;
            Stack<GroupHeaderBand> stack = new Stack<GroupHeaderBand>();
            for (int i = 0; i < sections.Count; i++)
            {
                Section section = sections[i];
                if (section.Kind == AreaSectionKind.ReportHeader)
                {
                    LoadReportTitle(section);
                }
                else if (section.Kind == AreaSectionKind.PageHeader)
                {
                    LoadPageHeader(section);
                }
                else if (section.Kind == AreaSectionKind.GroupHeader)
                {
                    if (groupHeader != null)
                    {
                        stack.Push(groupHeader);
                    }
                    groupHeader = new GroupHeaderBand();
                    if (stack.Count > 0)
                    {
                        stack.Peek().AddChild(groupHeader);
                    }
                    else
                    {
                        page.Bands.Add(groupHeader);
                    }
                    groupHeader.CreateUniqueName();
                    LoadBand(section, groupHeader);
                }
                else if (section.Kind == AreaSectionKind.Detail && groupHeader != null)
                {
                    detail = new DataBand();
                    if (groupHeader.Data == null)
                    {
                        groupHeader.Data = detail;
                    }
                    else
                    {
                        groupHeader.Data.AddChild(detail);
                    }
                    detail.CreateUniqueName();
                    LoadBand(section, detail);
                }
                else if (section.Kind == AreaSectionKind.GroupFooter && groupHeader != null)
                {
                    GroupFooterBand groupFooter = new GroupFooterBand();
                    groupHeader.GroupFooter = groupFooter;
                    groupFooter.Name = groupHeader.Name.Replace(groupHeader.BaseName, groupFooter.BaseName);
                    if (String.IsNullOrEmpty(groupFooter.Name))
                    {
                        groupFooter.CreateUniqueName();
                    }
                    LoadBand(section, groupFooter);
                    if (stack.Count > 0)
                    {
                        groupHeader = stack.Pop();
                    }
                }
                else if (section.Kind == AreaSectionKind.PageFooter)
                {
                    LoadPageFooter(section);
                }
                else if (section.Kind == AreaSectionKind.ReportFooter)
                {
                    LoadReportSummary(section);
                }
                else
                {
                    LoadData(section);
                }
            }
        }

        private void LoadReport()
        {
            page = ComponentsFactory.CreateReportPage(Report);
            LoadReportInfo();
            LoadPrintSettings();
            LoadPageSettings();
            LoadSections();
        }

        #endregion // Private Methods

        #region Protected Methods

        /// <inheritdoc/>
        protected override string GetFilter()
        {
            return new FastReport.Utils.MyRes("FileFilters").Get("RptFile");
        }

        #endregion // Protected Methods

        #region Public Methods

        /// <inheritdoc/>
        public override void LoadReport(Report report, string filename)
        {
            Report = report;
            Report.Clear();
            crystalReport.FileName = filename;
            crystalReport.Load();
            LoadReport();
        }

        #endregion // Public Methods
    }
}
