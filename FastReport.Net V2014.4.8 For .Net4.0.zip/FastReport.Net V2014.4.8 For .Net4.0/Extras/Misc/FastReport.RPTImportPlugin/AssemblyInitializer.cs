using System;
using System.Collections.Generic;
using System.Text;
using FastReport.Utils;
using FastReport.Design;

namespace FastReport.Design.ImportPlugins.RPT
{
    public class AssemblyInitializer : AssemblyInitializerBase
    {
        public AssemblyInitializer()
        {
            DesignerPlugins.Add(typeof(RPTImportPlugin));
        }
    }
}