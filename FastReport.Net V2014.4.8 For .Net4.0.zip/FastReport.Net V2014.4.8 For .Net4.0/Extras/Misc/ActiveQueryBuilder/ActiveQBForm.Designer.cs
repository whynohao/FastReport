namespace FastReport.Forms
{
  partial class ActiveQBForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ActiveQBForm));
      this.queryBuilder1 = new ActiveDatabaseSoftware.ActiveQueryBuilder.QueryBuilder();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.btnOK = new System.Windows.Forms.ToolStripButton();
      this.btnCancel = new System.Windows.Forms.ToolStripButton();
      this.tabControl1 = new System.Windows.Forms.TabControl();
      this.tabPage1 = new System.Windows.Forms.TabPage();
      this.splitContainer1 = new System.Windows.Forms.SplitContainer();
      this.tabPage3 = new System.Windows.Forms.TabPage();
      this.dataGridView1 = new System.Windows.Forms.DataGridView();
      this.toolStrip1.SuspendLayout();
      this.tabControl1.SuspendLayout();
      this.tabPage1.SuspendLayout();
      this.splitContainer1.Panel1.SuspendLayout();
      this.splitContainer1.SuspendLayout();
      this.tabPage3.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
      this.SuspendLayout();
      // 
      // queryBuilder1
      // 
      this.queryBuilder1.AddObjectFormOptions.MinimumSize = new System.Drawing.Size(430, 430);
      this.queryBuilder1.CriteriaListOptions.CriteriaListFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
      this.queryBuilder1.DiagramObjectColor = System.Drawing.SystemColors.Window;
      this.queryBuilder1.DiagramObjectFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
      this.queryBuilder1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.queryBuilder1.ExpressionEditor = null;
      this.queryBuilder1.FieldListOptions.DescriptionColumnOptions.Color = System.Drawing.Color.LightBlue;
      this.queryBuilder1.FieldListOptions.MarkColumnOptions.PKIcon = ((System.Drawing.Image)(resources.GetObject("resource.PKIcon")));
      this.queryBuilder1.FieldListOptions.NameColumnOptions.Color = System.Drawing.SystemColors.WindowText;
      this.queryBuilder1.FieldListOptions.NameColumnOptions.PKColor = System.Drawing.SystemColors.WindowText;
      this.queryBuilder1.FieldListOptions.TypeColumnOptions.Color = System.Drawing.SystemColors.GrayText;
      this.queryBuilder1.Location = new System.Drawing.Point(0, 0);
      this.queryBuilder1.MetadataProvider = null;
      this.queryBuilder1.MetadataTreeOptions.ImageList = null;
      this.queryBuilder1.MetadataTreeOptions.ProceduresNodeText = null;
      this.queryBuilder1.MetadataTreeOptions.SynonymsNodeText = null;
      this.queryBuilder1.MetadataTreeOptions.TablesNodeText = null;
      this.queryBuilder1.MetadataTreeOptions.ViewsNodeText = null;
      this.queryBuilder1.Name = "queryBuilder1";
      this.queryBuilder1.QueryStructureTreeOptions.ImageList = null;
      this.queryBuilder1.QueryStructureTreeOptions.TreeWidth = 160;
      this.queryBuilder1.Size = new System.Drawing.Size(651, 355);
      this.queryBuilder1.SleepModeText = null;
      this.queryBuilder1.SnapSize = new System.Drawing.Size(5, 5);
      this.queryBuilder1.SyntaxProvider = null;
      this.queryBuilder1.TabIndex = 1;
      this.queryBuilder1.TreeFont = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
      this.queryBuilder1.SQLUpdated += new System.EventHandler(this.queryBuilder1_SQLUpdated);
      // 
      // toolStrip1
      // 
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnOK,
            this.btnCancel});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new System.Drawing.Size(665, 25);
      this.toolStrip1.TabIndex = 2;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // btnOK
      // 
      this.btnOK.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.btnOK.Image = ((System.Drawing.Image)(resources.GetObject("btnOK.Image")));
      this.btnOK.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.btnOK.Name = "btnOK";
      this.btnOK.Size = new System.Drawing.Size(23, 22);
      this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
      // 
      // btnCancel
      // 
      this.btnCancel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
      this.btnCancel.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.btnCancel.Name = "btnCancel";
      this.btnCancel.Size = new System.Drawing.Size(23, 22);
      this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
      // 
      // tabControl1
      // 
      this.tabControl1.Controls.Add(this.tabPage1);
      this.tabControl1.Controls.Add(this.tabPage3);
      this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.tabControl1.Location = new System.Drawing.Point(0, 25);
      this.tabControl1.Name = "tabControl1";
      this.tabControl1.SelectedIndex = 0;
      this.tabControl1.Size = new System.Drawing.Size(665, 463);
      this.tabControl1.TabIndex = 3;
      this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
      // 
      // tabPage1
      // 
      this.tabPage1.Controls.Add(this.splitContainer1);
      this.tabPage1.Location = new System.Drawing.Point(4, 22);
      this.tabPage1.Name = "tabPage1";
      this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
      this.tabPage1.Size = new System.Drawing.Size(657, 437);
      this.tabPage1.TabIndex = 0;
      this.tabPage1.Text = "Designer";
      this.tabPage1.UseVisualStyleBackColor = true;
      // 
      // splitContainer1
      // 
      this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.splitContainer1.Location = new System.Drawing.Point(3, 3);
      this.splitContainer1.Name = "splitContainer1";
      this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
      // 
      // splitContainer1.Panel1
      // 
      this.splitContainer1.Panel1.Controls.Add(this.queryBuilder1);
      this.splitContainer1.Size = new System.Drawing.Size(651, 431);
      this.splitContainer1.SplitterDistance = 355;
      this.splitContainer1.TabIndex = 2;
      this.splitContainer1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitContainer1_SplitterMoved);
      // 
      // tabPage3
      // 
      this.tabPage3.Controls.Add(this.dataGridView1);
      this.tabPage3.Location = new System.Drawing.Point(4, 22);
      this.tabPage3.Name = "tabPage3";
      this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
      this.tabPage3.Size = new System.Drawing.Size(657, 437);
      this.tabPage3.TabIndex = 2;
      this.tabPage3.Text = "Result";
      this.tabPage3.UseVisualStyleBackColor = true;
      // 
      // dataGridView1
      // 
      this.dataGridView1.AllowUserToAddRows = false;
      this.dataGridView1.AllowUserToDeleteRows = false;
      this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dataGridView1.Location = new System.Drawing.Point(3, 3);
      this.dataGridView1.Name = "dataGridView1";
      this.dataGridView1.RowHeadersVisible = false;
      this.dataGridView1.Size = new System.Drawing.Size(651, 431);
      this.dataGridView1.TabIndex = 0;
      // 
      // ActiveQBForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
      this.BackColor = System.Drawing.SystemColors.Window;
      this.ClientSize = new System.Drawing.Size(665, 488);
      this.Controls.Add(this.tabControl1);
      this.Controls.Add(this.toolStrip1);
      this.Font = new System.Drawing.Font("Tahoma", 8F);
      this.KeyPreview = true;
      this.MinimizeBox = false;
      this.Name = "ActiveQBForm";
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
      this.Text = "Query Designer";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ActiveQBForm_FormClosing);
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.tabControl1.ResumeLayout(false);
      this.tabPage1.ResumeLayout(false);
      this.splitContainer1.Panel1.ResumeLayout(false);
      this.splitContainer1.ResumeLayout(false);
      this.tabPage3.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private ActiveDatabaseSoftware.ActiveQueryBuilder.QueryBuilder queryBuilder1;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton btnOK;
    private System.Windows.Forms.ToolStripButton btnCancel;
    private System.Windows.Forms.TabControl tabControl1;
    private System.Windows.Forms.TabPage tabPage1;
    private System.Windows.Forms.TabPage tabPage3;
    private System.Windows.Forms.DataGridView dataGridView1;
    private System.Windows.Forms.SplitContainer splitContainer1;

  }
}
