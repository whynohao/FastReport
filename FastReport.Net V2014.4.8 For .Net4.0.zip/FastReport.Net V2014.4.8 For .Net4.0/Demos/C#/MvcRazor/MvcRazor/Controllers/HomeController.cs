﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using System.Text;
using System.IO;
using FastReport;
using FastReport.Web;
using FastReport.Utils;
using FastReport.Export.Pdf;
using System.Web.UI.WebControls;

namespace MvcRazor.Controllers
{
    public class HomeController : Controller
    {
        private WebReport webReport = new WebReport();

        public ActionResult Index()
        {
            SetReport();

            webReport.Width = 700;// Unit.Percentage(100);
            webReport.Height = 800;// Unit.Percentage(100); 
            webReport.ToolbarIconsStyle = ToolbarIconsStyle.Black;
            
            webReport.ShowExports = false;
            webReport.ShowPrint = false;

            ViewBag.WebReport = webReport;
            return View();
        }

        public ActionResult FitPage()
        {
            SetReport();

            webReport.Width = Unit.Percentage(100);
            webReport.Height = Unit.Percentage(100);
            webReport.ToolbarIconsStyle = ToolbarIconsStyle.Black;

            ViewBag.WebReport = webReport;
            return View();
        }

        public ActionResult Designer()
        {
            webReport = new WebReport();
            string report_path = GetReportPath();
            System.Data.DataSet dataSet = new System.Data.DataSet();
            dataSet.ReadXml(report_path + "nwind.xml");
            webReport.Report.RegisterData(dataSet, "NorthWind");
            webReport.Report.Load(report_path + "Labels.frx");
            webReport.DesignReport = true;
            ViewBag.WebReport = webReport;
            return View();
        }

        private void SetReport()
        {
            string report_path = GetReportPath();

            //webReport.LocalizationFile = "~/Localization/French.frl";

            System.Data.DataSet dataSet = new System.Data.DataSet();
            dataSet.ReadXml(report_path + "nwind.xml");
            webReport.Report.RegisterData(dataSet, "NorthWind");
            webReport.Report.Load(report_path + "Simple List.frx");
            webReport.CurrentTab.Name = "Simple List";
            // tab 2
            Report report2 = new Report();
            report2.RegisterData(dataSet, "NorthWind");
            report2.Load(report_path + "Labels.frx");
            webReport.AddTab(report2, "Labels");
            // tab 3
            Report report3 = new Report();
            report3.RegisterData(dataSet, "NorthWind");
            report3.Load(report_path + "Master-Detail.frx");
            webReport.AddTab(report3, "Master-Detail");
        }

        public FileResult GetFile()
        {
            SetReport();
            webReport.Report.Prepare();
            Stream stream = new MemoryStream();
            webReport.Report.Export(new PDFExport(), stream);
            stream.Position = 0;            
            return File(stream, "application/pdf", "Report in PDF.pdf");
        }

        private string GetReportPath()
        {
            string report_path = Config.ApplicationFolder;
            using (XmlDocument xml = new XmlDocument())
            {
                xml.Load(report_path + "config.xml");
                foreach (XmlItem item in xml.Root.Items)
                    if (item.Name == "Config")
                        foreach (XmlItem configitem in item.Items)
                            if (configitem.Name == "Reports")
                                report_path += configitem.GetProp("Path");
            }
            return report_path;
        }

        public ActionResult Prepared()
        {
            WebReport webReport = new WebReport();
            webReport.Width = 750;
            webReport.Height = Unit.Percentage(100);
                        
            webReport.Tabs.Clear();
            
            // first
            Report firstReport = new Report();
            firstReport.LoadPrepared(this.Server.MapPath("~/App_Data/Prepared.fpx"));
            webReport.CurrentTab.Report = firstReport;
            webReport.CurrentTab.Name = "First prepared tab";
            webReport.CurrentTab.Properties.ReportDone = true;           
            
            // second
            Report secondReport = new Report();
            secondReport.LoadPrepared(this.Server.MapPath("~/App_Data/Prepared2.fpx"));
            webReport.AddTab(secondReport, "Second prepared tab", true);

            webReport.Tabs[0].Properties.ShowRefreshButton = false;
            webReport.Tabs[1].Properties.ShowRefreshButton = false;
            
            ViewBag.WebReport = webReport;
            return View();
        }

        public ActionResult Dialogs()
        {
            webReport.Width = 750;
            webReport.Height = 800;
            webReport.ToolbarBackgroundStyle = ToolbarBackgroundStyle.Light;
            webReport.ToolbarIconsStyle = ToolbarIconsStyle.Blue;
            webReport.ReportFile = this.Server.MapPath("~/App_Data/Dialogs.frx");
            ViewBag.WebReport = webReport;
            return View();
        }
    }
}
