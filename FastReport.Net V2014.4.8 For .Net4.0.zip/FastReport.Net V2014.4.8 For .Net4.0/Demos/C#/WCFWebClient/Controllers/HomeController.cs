﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FastReport;
using WCFWebClient.FastReportService;
using System.IO;
using FastReport.Web;

namespace WCFWebClient.Controllers
{
    public class HomeController : Controller
    {
        private WebReport webReport = new WebReport();

        public ActionResult Index()
        {           
            WebReport webReport = new WebReport();
            webReport.Width = 600;
            webReport.Height = 800;
            webReport.ToolbarIconsStyle = ToolbarIconsStyle.Black;
            webReport.StartReport += new EventHandler(webReport_StartReport);
            ViewBag.WebReport = webReport;
            return View();
        }

        void webReport_StartReport(object sender, EventArgs e)
        {
            (sender as WebReport).ReportDone = true;
            FastReportServiceClient reportServiceClient = new FastReportServiceClient();
            reportServiceClient.Open();
            ReportItem reportItem = new ReportItem();
            reportItem.Path = @"Demo reports\Simple List.frx";
            GearItem gearItem = new GearItem();
            gearItem.Name = "FPX";
            (sender as WebReport).Report.LoadPrepared(reportServiceClient.GetReport(reportItem, gearItem));
            reportServiceClient.Close();            
        }

        public FileResult GetFile()
        {
            FastReportServiceClient reportServiceClient = new FastReportServiceClient();
            reportServiceClient.Open();
            ReportItem reportItem = new ReportItem();
            reportItem.Path = @"Demo reports\Simple List.frx";
            GearItem gearItem = new GearItem();
            gearItem.Name = "PDF";
            Stream stream = reportServiceClient.GetReport(reportItem, gearItem);
            reportServiceClient.Close();            
            return File(stream, "application/pdf", "report.pdf");
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
