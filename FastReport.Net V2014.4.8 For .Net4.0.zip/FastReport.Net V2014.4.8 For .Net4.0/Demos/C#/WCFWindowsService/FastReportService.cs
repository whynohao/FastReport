﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.ServiceModel;

namespace FastReport.WindowsService
{
    public partial class FastReportService : ServiceBase
    {
        ServiceHost frHost;

        public FastReportService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            if (frHost != null)
                frHost.Close();
            frHost = new ServiceHost(typeof(FastReport.Service.ReportService));
            frHost.Open();
        }

        protected override void OnStop()
        {
            frHost.Close();
            frHost = null;
        }
    }
}
