﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WCFServiceTest.ReportService;
using System.IO;
using FastReport;
using System.Collections;

namespace WCFServiceTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            if (lbList.SelectedItem != null && cbGears.SelectedIndex != null)
            {
                // connect to che service
                FastReportServiceClient reportServiceClient = new FastReportServiceClient();
                reportServiceClient.Open();

                // set up report
                ReportItem reportItem = lbList.SelectedItem as ReportItem;
                // set up gear
                GearItem gearItem = cbGears.SelectedItem as GearItem;                                

                // get file from service
                Stream stream = reportServiceClient.GetReport(reportItem, gearItem);

                // prepare filename
                saveFileDialog.DefaultExt = gearItem.Name.ToLower();
                saveFileDialog.FileName = reportItem.Name;

                // show save dialog
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    // save export in file
                    using (FileStream file = new FileStream(saveFileDialog.FileName, FileMode.Create))
                        stream.CopyTo(file);
                    // open the file in default program
                    ShellExecute(saveFileDialog.FileName);
                }
                // close connection
                reportServiceClient.Close();
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            // connect to the service
            FastReportServiceClient reportServiceClient = new FastReportServiceClient();
            reportServiceClient.Open();
            
            // get list of available reports
            ReportItem[] reports = reportServiceClient.GetReportsList();

            // update list box
            lbList.Items.Clear();
            lbList.DisplayMember = "Name";
            foreach (ReportItem item in reports)
                lbList.Items.Add(item);

            // get list of available gear
            GearItem[] gears = reportServiceClient.GetGearList();

            // update gear list
            cbGears.Items.Clear();
            cbGears.DisplayMember = "Name";
            foreach (GearItem gear in gears)
                cbGears.Items.Add(gear);

            // close connection
            reportServiceClient.Close();

            // reset selections
            if (lbList.Items.Count > 0)
                lbList.SelectedIndex = 0;
            if (cbGears.Items.Count > 0)
                cbGears.SelectedIndex = 0;
        }
        
        private void btnOpen_Click(object sender, EventArgs e)
        {
            // connect to the service
            FastReportServiceClient reportServiceClient = new FastReportServiceClient();
            reportServiceClient.Open();

            // make new report item
            ReportItem reportItem = new ReportItem();
            if (lbList.SelectedItem != null)
            {
                // set up report path
                reportItem.Path = (lbList.SelectedItem as ReportItem).Path;
                // create new gear
                GearItem gearItem = new GearItem();
                gearItem.Name = "FPX";
                // get report from service
                Report report = new Report();
                report.LoadPrepared(reportServiceClient.GetReport(reportItem, gearItem));
                // show report
                report.ShowPrepared();
            }
            // close connection
            reportServiceClient.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnRefresh_Click(sender, e);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbDesc.Clear();
            tbDesc.AppendText("Path: " + (lbList.SelectedItem as ReportItem).Path + "\n");
            tbDesc.AppendText((lbList.SelectedItem as ReportItem).Description);
        }

        private void ShellExecute(string fileName)
        {
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.EnableRaisingEvents = false;
            proc.StartInfo.FileName = fileName;
            proc.Start();
        }
    }
}
